function f = f(alpha,t,tap)
f = func1(t,alpha)-func2(t,alpha)-t^2+t+(t-tao)^2+(t-tao)+test1(tao,1)
end
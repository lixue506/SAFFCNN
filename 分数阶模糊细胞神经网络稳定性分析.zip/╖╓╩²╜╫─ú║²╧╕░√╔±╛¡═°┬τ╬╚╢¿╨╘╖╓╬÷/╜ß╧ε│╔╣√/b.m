 function b=b(h, alpha, n, j)
        b=h^alpha*((n-j+1)^alpha-(n-j)^alpha)/alpha
end
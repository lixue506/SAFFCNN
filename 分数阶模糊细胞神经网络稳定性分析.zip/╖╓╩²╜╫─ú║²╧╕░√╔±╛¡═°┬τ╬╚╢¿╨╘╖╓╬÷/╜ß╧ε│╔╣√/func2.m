function func2=func2(t,alpha)
    func2 = t^(1-alpha)/gamma(2-alpha)
end

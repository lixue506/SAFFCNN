function test1 = test1(tao,t)
    test1 = 2*tao*t-tao^2-tao
end

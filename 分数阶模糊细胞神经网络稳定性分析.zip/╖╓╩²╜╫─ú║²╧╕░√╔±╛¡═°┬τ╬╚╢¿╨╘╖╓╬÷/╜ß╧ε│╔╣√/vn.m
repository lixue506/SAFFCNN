function vn=vn(n,m,xgm)
if m==1
    vn = xgm*ynp(m,t,h,alpha,n)+(1-xgm)*yn(m,t,h,alpha,n-1)
else
    vn = xgm*yn()+(1-xgm)*()
end
end
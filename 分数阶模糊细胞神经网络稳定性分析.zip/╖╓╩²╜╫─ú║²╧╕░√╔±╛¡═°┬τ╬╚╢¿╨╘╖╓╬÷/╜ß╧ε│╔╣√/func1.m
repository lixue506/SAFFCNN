function func1 = func1(t,alpha)
    func1=2*t^(2-alpha)/gamma(3-alpha)
end

        